from datetime import datetime, timezone
from flask_login import UserMixin
from sqlalchemy.orm import relationship, synonym, validates
from database import db
import uuid

class User(UserMixin, db.Model):
    """User account

    NOTE: id is currently the email string for legacy compatibility.
    The stable_id column provides a UUID that can become the PK in a future
    migration, allowing email changes without cascading FK updates.
    """
    __tablename__ = 'users'

    id = db.Column(db.String(120), primary_key=True)  # Email as ID (legacy)
    email = synonym('id')  # Backward compatibility for tests/code using User.email
    stable_id = db.Column(db.String(36), unique=True, default=lambda: str(uuid.uuid4()))
    password_hash = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # New fields for auth migration
    last_login = db.Column(db.DateTime)
    ip_address = db.Column(db.String(50))
    mac_address = db.Column(db.String(50))
    hostname = db.Column(db.String(100))
    display_name = db.Column(db.String(100))
    
    # Admin flag for role-based access control
    is_admin = db.Column(db.Boolean, default=False, nullable=False, index=True)

    # Ban/Suspend
    is_banned = db.Column(db.Boolean, default=False, nullable=False)
    banned_until = db.Column(db.DateTime, nullable=True)  # NULL = permanent, set = temp ban
    ban_reason = db.Column(db.String(500), nullable=True)

    # Force password reset on next login
    force_password_reset = db.Column(db.Boolean, default=False, nullable=False)

    # Force email verification on next login (for users who pre-date the email verification system)
    force_email_verify = db.Column(db.Boolean, default=False, nullable=False)

    # Email verification
    email_verified = db.Column(db.Boolean, default=False, nullable=False)
    email_verify_token = db.Column(db.String(64), nullable=True, index=True)
    email_verify_token_expires = db.Column(db.DateTime, nullable=True)

    # Password reset
    reset_token = db.Column(db.String(64), nullable=True, index=True)
    reset_token_expires = db.Column(db.DateTime, nullable=True)

    # Resend-verification rate limiting (per-email, DB-backed, 4-hour window)
    verify_resend_count = db.Column(db.Integer, default=0, nullable=False)
    verify_resend_window_start = db.Column(db.DateTime, nullable=True)

    # Account lockout (failed login attempts)
    lockout_until = db.Column(db.DateTime, nullable=True)          # NULL = not locked
    lockout_count = db.Column(db.Integer, default=0, nullable=False)
    lockout_window_start = db.Column(db.DateTime, nullable=True)   # start of counting window

    # Pending email change (held until new address is verified)
    pending_email = db.Column(db.String(120), nullable=True)
    pending_email_token = db.Column(db.String(64), nullable=True, index=True)
    pending_email_token_expires = db.Column(db.DateTime, nullable=True)

    # Password change via OTP (new hash staged until email code is verified)
    pw_change_otp_hash = db.Column(db.String(64), nullable=True)
    pw_change_otp_expires = db.Column(db.DateTime, nullable=True)
    pw_change_pending_hash = db.Column(db.String(200), nullable=True)

    # Relationships — cascade so deleting a User removes all owned data
    teams = relationship('Team', backref='owner', lazy=True, cascade="all, delete-orphan")
    matches = relationship('Match', backref='user', lazy=True, cascade="all, delete-orphan")
    tournaments = relationship('Tournament', backref='owner', lazy=True, cascade="all, delete-orphan")

class Team(db.Model):
    """Cricket Team"""
    __tablename__ = 'teams'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id'), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    short_code = db.Column(db.String(10), nullable=False)
    home_ground = db.Column(db.String(100))
    pitch_preference = db.Column(db.String(50))
    team_color = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_draft = db.Column(db.Boolean, default=False)
    is_placeholder = db.Column(db.Boolean, default=False)  # True for BYE/TBD teams
    season_id = db.Column(db.Integer, db.ForeignKey('seasons.id', ondelete='CASCADE'), nullable=True, index=True)

    # Unique constraint: one short_code per user
    __table_args__ = (
        db.UniqueConstraint('user_id', 'short_code', name='uq_team_user_short_code'),
    )

    # Relationships
    profiles = relationship('TeamProfile', back_populates='team', cascade='all, delete-orphan')
    # Read-only convenience accessor — cascade is managed through profiles
    players = relationship('Player', viewonly=True)

    # Matches where this team played
    home_matches = relationship('Match', foreign_keys='Match.home_team_id', backref='home_team')
    away_matches = relationship('Match', foreign_keys='Match.away_team_id', backref='away_team')


class TeamProfile(db.Model):
    """Format-specific squad profile for a team (T20, ListA)."""
    __tablename__ = 'team_profiles'

    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(
        db.Integer,
        db.ForeignKey('teams.id', ondelete='CASCADE'),
        nullable=False,
        index=True,
    )
    format_type = db.Column(db.String(20), nullable=False)  # 'T20', 'ListA'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('team_id', 'format_type', name='uq_team_profile_format'),
    )

    team = relationship('Team', back_populates='profiles')
    players = relationship('Player', back_populates='profile', cascade='all, delete-orphan')

class Player(db.Model):
    """Player Identity & Career Stats"""
    __tablename__ = 'players'

    id = db.Column(db.Integer, primary_key=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False, index=True)
    # Profile this player belongs to (format-specific squad)
    profile_id = db.Column(
        db.Integer,
        db.ForeignKey('team_profiles.id', ondelete='CASCADE'),
        nullable=True,
        index=True,
    )
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50))  # Batsman, Bowler, All-rounder, Wicketkeeper

    # Skill Ratings (snapshot from last update)
    batting_rating = db.Column(db.Integer, default=0)
    bowling_rating = db.Column(db.Integer, default=0)
    fielding_rating = db.Column(db.Integer, default=0)

    # Technical Attributes
    batting_hand = db.Column(db.String(20))
    bowling_type = db.Column(db.String(50))
    bowling_hand = db.Column(db.String(20))

    # Identity flags
    is_captain = db.Column(db.Boolean, default=False)
    is_wicketkeeper = db.Column(db.Boolean, default=False)

    # Aggregate Career Stats (Updated after every match; tracked per profile = per format)
    matches_played = db.Column(db.Integer, default=0)
    total_runs = db.Column(db.Integer, default=0)
    total_balls_faced = db.Column(db.Integer, default=0)
    total_fours = db.Column(db.Integer, default=0)
    total_sixes = db.Column(db.Integer, default=0)
    total_fifties = db.Column(db.Integer, default=0)
    total_centuries = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    not_outs = db.Column(db.Integer, default=0)

    total_balls_bowled = db.Column(db.Integer, default=0)
    total_runs_conceded = db.Column(db.Integer, default=0)
    total_wickets = db.Column(db.Integer, default=0)
    total_maidens = db.Column(db.Integer, default=0)
    five_wicket_hauls = db.Column(db.Integer, default=0)
    best_bowling_wickets = db.Column(db.Integer, default=0)
    best_bowling_runs = db.Column(db.Integer, default=0)

    # Identity metadata only — never aggregate stats across users via these FKs.
    # Stats must stay strictly per-user (filter via Team.user_id).
    master_player_id = db.Column(
        db.Integer,
        db.ForeignKey('master_players.id', ondelete='SET NULL'),
        nullable=True,
        index=True,
    )
    user_player_id = db.Column(
        db.Integer,
        db.ForeignKey('user_players.id', ondelete='SET NULL'),
        nullable=True,
        index=True,
    )

    # Unique constraint: one player name per profile (format squad)
    # NOTE: uq_player_team_name is replaced by uq_player_profile_name via migration
    __table_args__ = (
        db.UniqueConstraint('profile_id', 'name', name='uq_player_profile_name'),
    )

    # Relationships
    profile = relationship('TeamProfile', back_populates='players')
    scorecard_entries = relationship('MatchScorecard', backref='player_ref', passive_deletes=True)

    @validates('master_player_id', 'user_player_id')
    def _validate_pool_fk_exclusive(self, key, value):
        # A Player row may link to the master pool XOR the user pool, never both.
        # Neither-set is allowed as a transitional state.
        if value is None:
            return value
        other = 'user_player_id' if key == 'master_player_id' else 'master_player_id'
        if getattr(self, other) is not None:
            raise ValueError(
                f"Player {self.id or '(new)'}: cannot set both master_player_id "
                f"and user_player_id — pool links are mutually exclusive."
            )
        return value


class MasterPlayer(db.Model):
    """Admin-curated global player pool entry."""
    __tablename__ = 'master_players'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50))
    batting_rating = db.Column(db.Integer, default=50)
    bowling_rating = db.Column(db.Integer, default=50)
    fielding_rating = db.Column(db.Integer, default=50)
    batting_hand = db.Column(db.String(20))
    bowling_type = db.Column(db.String(50))
    bowling_hand = db.Column(db.String(20))
    is_captain = db.Column(db.Boolean, default=False)
    is_wicketkeeper = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user_overrides = relationship('UserPlayer', back_populates='master_player', cascade='all, delete-orphan')

    __table_args__ = (
        db.UniqueConstraint('name', name='uq_master_player_name'),
    )


class UserPlayer(db.Model):
    """Per-user custom player or override of a MasterPlayer."""
    __tablename__ = 'user_players'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    master_player_id = db.Column(db.Integer, db.ForeignKey('master_players.id', ondelete='CASCADE'), nullable=True, index=True)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50))
    batting_rating = db.Column(db.Integer, default=50)
    bowling_rating = db.Column(db.Integer, default=50)
    fielding_rating = db.Column(db.Integer, default=50)
    batting_hand = db.Column(db.String(20))
    bowling_type = db.Column(db.String(50))
    bowling_hand = db.Column(db.String(20))
    is_captain = db.Column(db.Boolean, default=False)
    is_wicketkeeper = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship('User', backref=db.backref('pool_players', cascade='all, delete-orphan', passive_deletes=True))
    master_player = relationship('MasterPlayer', back_populates='user_overrides')

    __table_args__ = (
        db.UniqueConstraint('user_id', 'master_player_id', name='uq_user_master_override'),
        db.Index('ix_user_player_user_name', 'user_id', 'name'),
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  League / Season / SeasonTeam  (AUCTION-REDESIGN Phase 1)
#  The auction is a child of a Season. Seasons live under a League. SeasonTeam
#  wraps an empty Team row created for that season. The auction (added in
#  later phases) populates those Team rosters.
# ═══════════════════════════════════════════════════════════════════════════════

class League(db.Model):
    __tablename__ = 'leagues'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    short_code = db.Column(db.String(10), nullable=True)
    frequency = db.Column(db.String(20), default='one_time')  # one_time | recurring
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    owner = relationship('User', backref=db.backref('leagues', cascade='all, delete-orphan', passive_deletes=True))
    seasons = relationship('Season', back_populates='league', cascade='all, delete-orphan')

    __table_args__ = (
        db.UniqueConstraint('user_id', 'name', name='uq_league_user_name'),
    )


class Season(db.Model):
    __tablename__ = 'seasons'

    id = db.Column(db.Integer, primary_key=True)
    league_id = db.Column(db.Integer, db.ForeignKey('leagues.id', ondelete='CASCADE'), nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    format = db.Column(db.String(20), default='T20')             # T20 | ListA
    auction_mode = db.Column(db.String(20), default='traditional')  # traditional | draft
    status = db.Column(db.String(30), default='setup')
    # statuses: setup | teams_ready | auction_ready | auction_live | auction_paused | auction_done | archived
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    league = relationship('League', back_populates='seasons')
    season_teams = relationship('SeasonTeam', back_populates='season', cascade='all, delete-orphan')

    __table_args__ = (
        db.UniqueConstraint('league_id', 'name', name='uq_season_league_name'),
    )


class SeasonTeam(db.Model):
    """Wraps an empty Team row under a Season, with a manager access token."""
    __tablename__ = 'season_teams'

    id = db.Column(db.Integer, primary_key=True)
    season_id = db.Column(db.Integer, db.ForeignKey('seasons.id', ondelete='CASCADE'), nullable=False, index=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='CASCADE'), nullable=False, index=True)
    display_name = db.Column(db.String(200), nullable=False)
    access_token = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()))
    # Budget fields populated in Phase 2 (auction setup). Safe defaults for Phase 1.
    custom_budget = db.Column(db.BigInteger, nullable=True)
    purse_remaining = db.Column(db.BigInteger, default=0)
    players_bought = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    season = relationship('Season', back_populates='season_teams')
    team = relationship('Team', foreign_keys=[team_id])

    __table_args__ = (
        db.UniqueConstraint('season_id', 'display_name', name='uq_season_team_display_name'),
    )


# ═══════════════════════════════════════════════════════════════════════════════
#  Auction (Phase 2 — setup only; runtime fields populated in later phases)
#  One Auction row per Season (1:1). Categories and curated players live under
#  it. Snapshot copies of pool rows are taken at curation so later pool edits
#  don't mutate a live or completed auction.
# ═══════════════════════════════════════════════════════════════════════════════

class Auction(db.Model):
    __tablename__ = 'auctions'

    id = db.Column(db.Integer, primary_key=True)
    season_id = db.Column(
        db.Integer,
        db.ForeignKey('seasons.id', ondelete='CASCADE'),
        nullable=False, unique=True, index=True,
    )
    budget_mode = db.Column(db.String(20), default='uniform')   # uniform | custom
    uniform_budget = db.Column(db.BigInteger, default=0)
    bid_increment = db.Column(db.BigInteger, default=0)         # flat increment; 0 = next bid must be +1
    min_players_per_team = db.Column(db.Integer, default=12)
    max_players_per_team = db.Column(db.Integer, default=25)
    per_player_timer_seconds = db.Column(db.Integer, default=20)
    draft_pick_timer_seconds = db.Column(db.Integer, default=30)
    category_order_mode = db.Column(db.String(10), default='manual')  # manual | random
    category_order = db.Column(db.Text, default='[]')           # JSON [cat_id,...], frozen on finalize
    reauction_rounds = db.Column(db.Integer, default=0)
    reauction_price_reduction_pct = db.Column(db.Integer, default=0)
    current_round = db.Column(db.Integer, default=1)
    started_at = db.Column(db.DateTime, nullable=True)
    ended_at = db.Column(db.DateTime, nullable=True)

    # Phase 4 — live runtime state. Plain Integer (no SA-level FK) to avoid the
    # auctions⇄auction_players circular dependency at table-create time;
    # ON DELETE SET NULL is enforced at the SQL level by the migration.
    live_player_id = db.Column(db.Integer, nullable=True)
    lot_ends_at = db.Column(db.DateTime, nullable=True)
    lot_paused_remaining_ms = db.Column(db.Integer, nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    season = relationship(
        'Season',
        backref=db.backref('auction', uselist=False, cascade='all, delete-orphan', passive_deletes=True),
    )
    categories = relationship(
        'AuctionCategory', back_populates='auction',
        cascade='all, delete-orphan', order_by='AuctionCategory.display_order',
    )
    players = relationship(
        'AuctionPlayer', back_populates='auction',
        cascade='all, delete-orphan',
    )


class AuctionCategory(db.Model):
    __tablename__ = 'auction_categories'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    name = db.Column(db.String(100), nullable=False)
    display_order = db.Column(db.Integer, default=0)
    default_base_price = db.Column(db.BigInteger, nullable=True)   # null only valid in draft mode
    max_players = db.Column(db.Integer, default=15, nullable=True)  # pool-size cap for this category; null = no cap

    auction = relationship('Auction', back_populates='categories')
    players = relationship(
        'AuctionPlayer', back_populates='category',
        cascade='all, delete-orphan',
    )

    __table_args__ = (
        db.UniqueConstraint('auction_id', 'name', name='uq_auction_category_name'),
    )


class AuctionPlayer(db.Model):
    __tablename__ = 'auction_players'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    category_id = db.Column(
        db.Integer,
        db.ForeignKey('auction_categories.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    master_player_id = db.Column(db.Integer, db.ForeignKey('master_players.id', ondelete='SET NULL'), nullable=True)
    user_player_id = db.Column(db.Integer, db.ForeignKey('user_players.id', ondelete='SET NULL'), nullable=True)

    # Snapshotted pool fields (copied at curation, immutable during auction)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50))
    batting_rating = db.Column(db.Integer, default=50)
    bowling_rating = db.Column(db.Integer, default=50)
    fielding_rating = db.Column(db.Integer, default=50)
    batting_hand = db.Column(db.String(20))
    bowling_type = db.Column(db.String(50))
    bowling_hand = db.Column(db.String(20))

    base_price_override = db.Column(db.BigInteger, nullable=True)  # null = use category default
    lot_order = db.Column(db.Integer, nullable=True)               # ordering within category

    # Runtime fields (populated in Phase 4+; defaults safe for Phase 2)
    status = db.Column(db.String(20), default='upcoming')          # upcoming | live | sold | unsold
    sold_to_season_team_id = db.Column(
        db.Integer,
        db.ForeignKey('season_teams.id', ondelete='SET NULL'),
        nullable=True,
    )
    sold_price = db.Column(db.BigInteger, nullable=True)
    sold_in_round = db.Column(db.Integer, nullable=True)

    auction = relationship('Auction', back_populates='players')
    category = relationship('AuctionCategory', back_populates='players')

    @validates('master_player_id', 'user_player_id')
    def _validate_pool_fk_exclusive(self, key, value):
        if value is None:
            return value
        other = 'user_player_id' if key == 'master_player_id' else 'master_player_id'
        if getattr(self, other) is not None:
            raise ValueError(
                f"AuctionPlayer {self.id or '(new)'}: master_player_id and user_player_id are mutually exclusive."
            )
        return value


class DraftPick(db.Model):
    """One slot in a draft auction. Generated ahead of each round in snake
    order. A pick is either `pending` (the team has not yet acted), `picked`
    (a player was chosen), or `missed` (the timer expired). Missed picks
    create a catch-up carryover pick in a later round so the team's slot
    count is preserved.
    """
    __tablename__ = 'draft_picks'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    round = db.Column(db.Integer, nullable=False)
    pick_order_in_round = db.Column(db.Integer, nullable=False)
    season_team_id = db.Column(
        db.Integer,
        db.ForeignKey('season_teams.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    # Null if missed; otherwise the chosen player. ON DELETE SET NULL at
    # DB level via the migration to tolerate mid-auction player removals.
    auction_player_id = db.Column(db.Integer, nullable=True)
    category_id = db.Column(
        db.Integer,
        db.ForeignKey('auction_categories.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    is_carryover = db.Column(db.Boolean, default=False, nullable=False)
    carryover_from_round = db.Column(db.Integer, nullable=True)
    picked_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(20), default='pending', nullable=False)  # pending | picked | missed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.Index('ix_draft_picks_auction_round', 'auction_id', 'round'),
        db.Index('ix_draft_picks_queue', 'auction_id', 'status', 'round', 'pick_order_in_round'),
    )


class AuctionBid(db.Model):
    """Every accepted bid in a traditional auction — append-only history.

    In Phase 4 this was intentionally in-memory; Phase 8 persists so the
    organizer has a replayable trail. Rejected bids are NOT stored (noise).
    """
    __tablename__ = 'auction_bids'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    auction_player_id = db.Column(
        db.Integer,
        db.ForeignKey('auction_players.id', ondelete='SET NULL'),
        nullable=True, index=True,
    )
    season_team_id = db.Column(
        db.Integer,
        db.ForeignKey('season_teams.id', ondelete='SET NULL'),
        nullable=True, index=True,
    )
    amount = db.Column(db.BigInteger, nullable=False)
    round = db.Column(db.Integer, nullable=False, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.Index('ix_auction_bid_auction_created', 'auction_id', 'created_at'),
    )


class AuctionAuditLog(db.Model):
    """Organizer actions + key system events for a given auction. Readable
    from the live console; persists for post-auction review/export.

    `action` is a short enum-like string: `auction.start`, `lot.open`,
    `lot.sold`, `lot.unsold`, `lot.reversed`, `pick.submitted`,
    `pick.missed`, `round.advance`, `roster.synced`, `tournament.created`,
    etc. `payload` is JSON-stringified context (team names, amounts, etc.)
    so the UI can render without joining across tables.
    """
    __tablename__ = 'auction_audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    action = db.Column(db.String(50), nullable=False)
    actor_type = db.Column(db.String(20), nullable=False, default='system')  # system | organizer | team
    actor_label = db.Column(db.String(120), nullable=True)  # organizer email / team display_name / 'system'
    payload = db.Column(db.Text, nullable=True)  # JSON
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.Index('ix_auction_audit_auction_created', 'auction_id', 'created_at'),
        db.Index('ix_auction_audit_action', 'action'),
    )


class AuctionChatMessage(db.Model):
    """Flat per-auction chat room. Organizer has full moderation control."""
    __tablename__ = 'auction_chat_messages'

    id = db.Column(db.Integer, primary_key=True)
    auction_id = db.Column(
        db.Integer,
        db.ForeignKey('auctions.id', ondelete='CASCADE'),
        nullable=False, index=True,
    )
    sender_type = db.Column(db.String(20), nullable=False)  # organizer | team
    # Null for organizer messages; set for team messages.
    season_team_id = db.Column(
        db.Integer,
        db.ForeignKey('season_teams.id', ondelete='SET NULL'),
        nullable=True, index=True,
    )
    sender_label = db.Column(db.String(100), nullable=False)  # "Organizer" or team's display_name snapshot
    body = db.Column(db.Text, nullable=False)
    deleted_at = db.Column(db.DateTime, nullable=True)  # soft-delete for moderation visibility
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    auction = relationship(
        'Auction',
        backref=db.backref('chat_messages', cascade='all, delete-orphan', passive_deletes=True),
    )


class Match(db.Model):
    """Match Archive Record"""
    __tablename__ = 'matches'
    
    id = db.Column(db.String(36), primary_key=True)  # UUID
    user_id = db.Column(db.String(120), db.ForeignKey('users.id'))
    
    home_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='SET NULL'), index=True)
    away_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='SET NULL'), index=True)

    winner_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='SET NULL'), nullable=True, index=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournaments.id', ondelete='SET NULL'), nullable=True, index=True)
    
    # Match Details
    venue = db.Column(db.String(100))
    pitch_type = db.Column(db.String(50))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    result_description = db.Column(db.String(200)) # e.g., "CSK won by 4 wickets"
    
    # Scores
    home_team_score = db.Column(db.Integer)
    home_team_wickets = db.Column(db.Integer)
    home_team_overs = db.Column(db.String(10))

    away_team_score = db.Column(db.Integer)
    away_team_wickets = db.Column(db.Integer)
    away_team_overs = db.Column(db.String(10))
    
    # Margin of Victory
    margin_type = db.Column(db.String(10))  # 'runs', 'wickets', or 'tie'
    margin_value = db.Column(db.Integer)    # Number of runs/wickets
    
    # Toss Information
    toss_winner_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='SET NULL'), nullable=True)
    toss_decision = db.Column(db.String(10))  # 'Bat' or 'Bowl'
    
    # Match Format
    match_format = db.Column(db.String(20), default='T20')
    overs_per_side = db.Column(db.Integer, default=20)
    is_day_night = db.Column(db.Boolean, default=False)
    
    # Technical
    match_json_path = db.Column(db.String(255)) # Path to legacy full JSON
    
    # Relationships
    scorecards = relationship('MatchScorecard', backref='match', cascade="all, delete-orphan")
    toss_winner = relationship('Team', foreign_keys=[toss_winner_team_id])

class MatchScorecard(db.Model):
    """Detailed stats for a player in a specific match"""
    __tablename__ = 'match_scorecards'
    
    id = db.Column(db.Integer, primary_key=True)
    match_id = db.Column(db.String(36), db.ForeignKey('matches.id'), nullable=False, index=True)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id', ondelete='CASCADE'), nullable=False, index=True)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False, index=True)
    innings_number = db.Column(db.Integer, default=1, nullable=False)
    record_type = db.Column(db.String(20), default="batting", nullable=False)
    position = db.Column(db.Integer, nullable=True)
    
    # Batting
    runs = db.Column(db.Integer, default=0)
    balls = db.Column(db.Integer, default=0)
    fours = db.Column(db.Integer, default=0)
    sixes = db.Column(db.Integer, default=0)
    is_out = db.Column(db.Boolean, default=False)
    wicket_type = db.Column(db.String(50), nullable=True)
    
    # Bowling
    overs = db.Column(db.String(10), default='0.0')
    balls_bowled = db.Column(db.Integer, default=0)
    runs_conceded = db.Column(db.Integer, default=0)
    wickets = db.Column(db.Integer, default=0)
    maidens = db.Column(db.Integer, default=0)
    wides = db.Column(db.Integer, default=0)
    noballs = db.Column(db.Integer, default=0)
    
    # Fielding
    catches = db.Column(db.Integer, default=0)
    run_outs = db.Column(db.Integer, default=0)
    stumpings = db.Column(db.Integer, default=0)

    # New fields for detailed scorecard
    wicket_taker_name = db.Column(db.String(100), nullable=True)
    fielder_name = db.Column(db.String(100), nullable=True)
    
    # Detailed Batting Stats
    ones = db.Column(db.Integer, default=0)
    twos = db.Column(db.Integer, default=0)
    threes = db.Column(db.Integer, default=0)
    dot_balls = db.Column(db.Integer, default=0)
    strike_rate = db.Column(db.Float, default=0.0)
    batting_position = db.Column(db.Integer)
    
    # Detailed Bowling Stats
    dot_balls_bowled = db.Column(db.Integer, default=0)
    wickets_bowled = db.Column(db.Integer, default=0)
    wickets_caught = db.Column(db.Integer, default=0)
    wickets_lbw = db.Column(db.Integer, default=0)
    wickets_stumped = db.Column(db.Integer, default=0)
    wickets_run_out = db.Column(db.Integer, default=0)
    wickets_hit_wicket = db.Column(db.Integer, default=0)

class Tournament(db.Model):
    """Tournament / League Container"""
    __tablename__ = 'tournaments'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='Active')  # Active, Completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Tournament Mode Configuration
    # Modes: 'round_robin', 'double_round_robin', 'knockout',
    #        'round_robin_knockout', 'double_round_robin_knockout', 'ipl_style', 'custom_series'
    mode = db.Column(db.String(50), default='round_robin', nullable=False)

    # Cricket format for all matches in this tournament (T20, ListA)
    format_type = db.Column(db.String(20), default='T20', nullable=False)

    # Current stage for multi-stage tournaments
    # Stages: 'league', 'qualifier', 'eliminator', 'semifinal', 'final', 'completed'
    current_stage = db.Column(db.String(30), default='league', nullable=False)

    # Number of teams that qualify from league stage (for knockout/IPL modes)
    # Default 4 for IPL-style, can be 2/4/8 for knockout modes
    playoff_teams = db.Column(db.Integer, default=4, nullable=False)

    # Custom series configuration (JSON string for flexibility)
    # Example: {"matches": [{"home": 1, "away": 2, "venue": "home"}, ...], "series_name": "Ashes"}
    series_config = db.Column(db.Text, nullable=True)

    # Relationships
    participating_teams = relationship('TournamentTeam', backref='tournament', cascade="all, delete-orphan")
    fixtures = relationship('TournamentFixture', backref='tournament', cascade="all, delete-orphan")
    player_stats_cache = relationship('TournamentPlayerStatsCache', backref='tournament', cascade="all, delete-orphan")

class MatchPartnership(db.Model):
    """Batting partnership records for each innings"""
    __tablename__ = 'match_partnerships'
    
    id = db.Column(db.Integer, primary_key=True)
    match_id = db.Column(db.String(36), db.ForeignKey('matches.id'), nullable=False)
    innings_number = db.Column(db.Integer, nullable=False)   # 1 or 2
    wicket_number = db.Column(db.Integer, nullable=False)   # 1st wicket, 2nd wicket, etc.
    
    # Partnership participants
    batsman1_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    batsman2_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    
    # Partnership statistics
    runs = db.Column(db.Integer, default=0)
    balls = db.Column(db.Integer, default=0)
    batsman1_contribution = db.Column(db.Integer, default=0)
    batsman2_contribution = db.Column(db.Integer, default=0)
    
    # Partnership duration
    start_over = db.Column(db.Float)
    end_over = db.Column(db.Float)
    
    # Relationships
    batsman1 = relationship('Player', foreign_keys=[batsman1_id])
    batsman2 = relationship('Player', foreign_keys=[batsman2_id])
    match = relationship('Match', backref=db.backref('partnerships', cascade="all, delete-orphan"))
    
    # Indexes for efficient queries
    __table_args__ = (
        db.Index('ix_partnership_match_innings', 'match_id', 'innings_number'),
    )

class TournamentPlayerStatsCache(db.Model):
    """Cached player statistics for a specific tournament"""
    __tablename__ = 'tournament_player_stats_cache'

    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournaments.id'), nullable=False)
    player_id = db.Column(db.Integer, db.ForeignKey('players.id'), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id'), nullable=False)

    # Batting Stats
    matches_played = db.Column(db.Integer, default=0)
    innings_batted = db.Column(db.Integer, default=0)
    runs_scored = db.Column(db.Integer, default=0)
    balls_faced = db.Column(db.Integer, default=0)
    fours = db.Column(db.Integer, default=0)
    sixes = db.Column(db.Integer, default=0)
    not_outs = db.Column(db.Integer, default=0)
    highest_score = db.Column(db.Integer, default=0)
    fifties = db.Column(db.Integer, default=0)
    centuries = db.Column(db.Integer, default=0)
    batting_average = db.Column(db.Float, default=0.0)
    batting_strike_rate = db.Column(db.Float, default=0.0)

    # Bowling Stats
    innings_bowled = db.Column(db.Integer, default=0)
    overs_bowled = db.Column(db.String(10), default='0.0')
    runs_conceded = db.Column(db.Integer, default=0)
    wickets_taken = db.Column(db.Integer, default=0)
    maidens = db.Column(db.Integer, default=0)
    best_bowling_wickets = db.Column(db.Integer, default=0)
    best_bowling_runs = db.Column(db.Integer, default=0)
    five_wicket_hauls = db.Column(db.Integer, default=0)
    bowling_average = db.Column(db.Float, default=0.0)
    bowling_economy = db.Column(db.Float, default=0.0)
    bowling_strike_rate = db.Column(db.Float, default=0.0)

    # Fielding Stats
    catches = db.Column(db.Integer, default=0)
    run_outs = db.Column(db.Integer, default=0)
    stumpings = db.Column(db.Integer, default=0)

    # Relationships
    player = relationship('Player')
    team = relationship('Team')

    __table_args__ = (
        db.UniqueConstraint('tournament_id', 'player_id', name='uq_tournament_player_cache'),
        db.Index('ix_tournament_player_cache_tournament_id', 'tournament_id'),
    )

class TournamentTeam(db.Model):
    """Team stats within a specific tournament"""
    __tablename__ = 'tournament_teams'

    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournaments.id'), nullable=False)
    team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='CASCADE'), nullable=False)

    # Standings Stats
    played = db.Column(db.Integer, default=0, nullable=False)
    won = db.Column(db.Integer, default=0, nullable=False)
    lost = db.Column(db.Integer, default=0, nullable=False)
    tied = db.Column(db.Integer, default=0, nullable=False)
    no_result = db.Column(db.Integer, default=0, nullable=False)
    points = db.Column(db.Integer, default=0, nullable=False)

    # NRR Components
    runs_scored = db.Column(db.Integer, default=0, nullable=False)
    overs_faced = db.Column(db.String(10), default='0.0', nullable=False)
    runs_conceded = db.Column(db.Integer, default=0, nullable=False)
    overs_bowled = db.Column(db.String(10), default='0.0', nullable=False)

    net_run_rate = db.Column(db.Float, default=0.0, nullable=False)

    # Relationship to access Team details (name, etc.)
    team = relationship('Team')

    # Ensure each team can only appear once per tournament
    __table_args__ = (
        db.UniqueConstraint('tournament_id', 'team_id', name='uq_tournament_team'),
    )

class TournamentFixture(db.Model):
    """Scheduled Match in a Tournament"""
    __tablename__ = 'tournament_fixtures'

    id = db.Column(db.Integer, primary_key=True)
    tournament_id = db.Column(db.Integer, db.ForeignKey('tournaments.id'), nullable=False)
    home_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='CASCADE'), nullable=True)
    away_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='CASCADE'), nullable=True)
    round_number = db.Column(db.Integer, default=1, nullable=False)
    status = db.Column(db.String(20), default='Scheduled', nullable=False)
    stage = db.Column(db.String(30), default='league', nullable=False)
    stage_description = db.Column(db.String(100), nullable=True)
    bracket_position = db.Column(db.Integer, nullable=True)
    match_id = db.Column(db.String(36), db.ForeignKey('matches.id', ondelete='SET NULL'), nullable=True)
    winner_team_id = db.Column(db.Integer, db.ForeignKey('teams.id', ondelete='SET NULL'), nullable=True)
    series_match_number = db.Column(db.Integer, nullable=True)
    standings_applied = db.Column(db.Boolean, default=False, nullable=False)

    # Relationships
    home_team = relationship('Team', foreign_keys=[home_team_id])
    away_team = relationship('Team', foreign_keys=[away_team_id])
    winner_team = relationship('Team', foreign_keys=[winner_team_id])
    match = relationship('Match')

    __table_args__ = (
        db.Index('ix_fixture_tournament_status', 'tournament_id', 'status'),
        db.Index('ix_fixture_tournament_stage', 'tournament_id', 'stage'),
    )

class AdminAuditLog(db.Model):
    """Persistent audit trail for all admin actions"""
    __tablename__ = 'admin_audit_log'

    id = db.Column(db.Integer, primary_key=True)
    admin_email = db.Column(db.String(120), nullable=False, index=True)
    action = db.Column(db.String(50), nullable=False)  # e.g. 'reset_password', 'delete_user', 'change_email'
    target = db.Column(db.String(200), nullable=True)   # target user/entity
    details = db.Column(db.Text, nullable=True)          # extra context (JSON or text)
    ip_address = db.Column(db.String(50), nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    __table_args__ = (
        db.Index('ix_audit_admin_action', 'admin_email', 'action'),
    )


class FailedLoginAttempt(db.Model):
    """Track failed login attempts for security monitoring"""
    __tablename__ = 'failed_login_attempts'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), nullable=False, index=True)
    ip_address = db.Column(db.String(50), nullable=True)
    user_agent = db.Column(db.String(300), nullable=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False, index=True)

    __table_args__ = (
        db.Index('ix_failed_login_ip', 'ip_address'),
    )


class BlockedIP(db.Model):
    """IP addresses blocked by admin"""
    __tablename__ = 'blocked_ips'

    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(50), nullable=False, unique=True)
    reason = db.Column(db.String(300), nullable=True)
    blocked_by = db.Column(db.String(120), nullable=False, default='system')
    blocked_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class ActiveSession(db.Model):
    """Track active user sessions for admin monitoring"""
    __tablename__ = 'active_sessions'

    id = db.Column(db.Integer, primary_key=True)
    session_token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id'), nullable=False, index=True)
    ip_address = db.Column(db.String(50), nullable=True)
    user_agent = db.Column(db.String(300), nullable=True)
    login_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    last_active = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    user = relationship('User', backref=db.backref('sessions', cascade='all, delete-orphan'))


class SiteCounter(db.Model):
    """Key-value store for site-wide counters (visits, matches simulated, etc.)"""
    __tablename__ = 'site_counters'

    key = db.Column(db.String(50), primary_key=True)
    value = db.Column(db.Integer, default=0, nullable=False)


class AnnouncementBanner(db.Model):
    """Single global announcement banner configured by admins."""
    __tablename__ = 'announcement_banner'

    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False, default="")
    is_enabled = db.Column(db.Boolean, nullable=False, default=False)
    color_preset = db.Column(db.String(20), nullable=False, default="urgent")
    position = db.Column(db.String(10), nullable=False, default="bottom")
    version = db.Column(db.Integer, nullable=False, default=1)
    updated_by = db.Column(db.String(120), db.ForeignKey('users.id'), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    admin_user = relationship('User', foreign_keys=[updated_by])


class UserBannerDismissal(db.Model):
    """Per-user dismissal state keyed by banner version."""
    __tablename__ = 'user_banner_dismissals'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    banner_version = db.Column(db.Integer, nullable=False)
    dismissed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = relationship('User', backref=db.backref('banner_dismissals', cascade='all, delete-orphan', passive_deletes=True))

    __table_args__ = (
        db.UniqueConstraint('user_id', 'banner_version', name='uq_user_banner_dismissal'),
        db.Index('ix_user_banner_dismissal_user_ver', 'user_id', 'banner_version'),
    )


class LoginHistory(db.Model):
    """Persistent log of every successful login and logout event"""
    __tablename__ = 'login_history'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    ip_address = db.Column(db.String(50), nullable=True)
    user_agent = db.Column(db.String(300), nullable=True)
    event = db.Column(db.String(10), default='login', nullable=False)  # 'login' or 'logout'
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    user = relationship('User', backref=db.backref('login_history', cascade='all, delete-orphan', passive_deletes=True))

    __table_args__ = (
        db.Index('ix_login_history_user_ts', 'user_id', 'timestamp'),
    )


class IPWhitelistEntry(db.Model):
    """IP addresses allowed when whitelist mode is enabled"""
    __tablename__ = 'ip_whitelist'

    id = db.Column(db.Integer, primary_key=True)
    ip_address = db.Column(db.String(50), nullable=False, unique=True)
    label = db.Column(db.String(100), nullable=True)
    added_by = db.Column(db.String(120), nullable=False)
    added_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)


class UserGroundConfig(db.Model):
    """Per-user ground conditions configuration.

    One row per user. When absent, the engine falls back to the factory
    defaults in config/ground_conditions_defaults.yaml.
    """
    __tablename__ = 'user_ground_configs'

    id         = db.Column(db.Integer, primary_key=True)
    user_id    = db.Column(db.String(120), db.ForeignKey('users.id'),
                           unique=True, nullable=False, index=True)
    config_json = db.Column(db.JSON, nullable=False)
    updated_at  = db.Column(db.DateTime, default=datetime.utcnow,
                            onupdate=datetime.utcnow)

    user = relationship('User', backref=db.backref(
        'ground_config', uselist=False, cascade='all, delete-orphan'))


class AuthEventLog(db.Model):
    """Log of notable auth events for admin review.

    Event types:
      resend_rate_limit   — user hit the verification-resend cap
      email_send_failure  — Resend API returned an error
      verify_token_expired — user clicked an expired verification link
      reset_token_expired  — user clicked an expired password-reset link
    """
    __tablename__ = 'auth_event_log'

    id = db.Column(db.Integer, primary_key=True)
    event_type = db.Column(db.String(30), nullable=False, index=True)
    email = db.Column(db.String(120), nullable=False, index=True)
    # Nullable — user may not exist (e.g. unknown email submitted to forgot-password)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    details = db.Column(db.Text, nullable=True)          # free-form JSON or text
    ip_address = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    # Admin workflow fields
    status = db.Column(db.String(20), nullable=False, default='pending')  # pending | contacted | resolved
    admin_notes = db.Column(db.Text, nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolved_by = db.Column(db.String(120), nullable=True)

    user = relationship('User', foreign_keys=[user_id],
                        backref=db.backref('auth_events', cascade='all, delete-orphan', passive_deletes=True))

    __table_args__ = (
        db.Index('ix_auth_event_log_status_type', 'status', 'event_type'),
    )


class ExceptionLog(db.Model):
    """App-wide exception / error tracking.

    Every caught or unhandled exception is recorded here so that admins
    can trace, evaluate, and debug issues across the entire application.
    """
    __tablename__ = 'exception_log'

    id                = db.Column(db.Integer, primary_key=True)
    exception_type    = db.Column(db.String(200), nullable=False)
    exception_message = db.Column(db.Text, nullable=False, default='')
    traceback         = db.Column(db.Text, nullable=True)
    module            = db.Column(db.String(200), nullable=True)
    function          = db.Column(db.String(200), nullable=True)
    line_number       = db.Column(db.Integer, nullable=True)
    filename          = db.Column(db.String(300), nullable=True)
    user_email        = db.Column(db.String(120), nullable=True)
    severity          = db.Column(db.String(10), nullable=False, default='error')
    source            = db.Column(db.String(30), nullable=False, default='backend')
    context_json      = db.Column(db.Text, nullable=True)
    request_id        = db.Column(db.String(64), nullable=True)
    handled           = db.Column(db.Boolean, nullable=False, default=True)
    resolved          = db.Column(db.Boolean, nullable=False, default=False)
    resolved_at       = db.Column(db.DateTime, nullable=True)
    resolved_by       = db.Column(db.String(120), nullable=True)
    fingerprint       = db.Column(db.String(64), nullable=True)
    occurrence_count  = db.Column(db.Integer, nullable=False, default=1)
    first_seen_at     = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    last_seen_at      = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    github_issue_number = db.Column(db.Integer, nullable=True)
    github_issue_url  = db.Column(db.String(300), nullable=True)
    github_sync_status = db.Column(db.String(20), nullable=True)
    github_sync_error = db.Column(db.Text, nullable=True)
    github_last_synced_at = db.Column(db.DateTime, nullable=True)
    timestamp         = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        db.Index('ix_exception_timestamp', 'timestamp'),
        db.Index('ix_exception_type_ts', 'exception_type', 'timestamp'),
        db.Index('ix_exception_source_ts', 'source', 'timestamp'),
        db.Index('ix_exception_resolved_ts', 'resolved', 'timestamp'),
        db.Index('ix_exception_fingerprint', 'fingerprint'),
    )


class IssueWebhookEvent(db.Model):
    """Audit + idempotency record for inbound GitHub webhook deliveries.

    GitHub re-delivers failed webhooks, so we MUST dedupe by `delivery_id`
    (the X-GitHub-Delivery header). One row per delivery — successful or
    not — gives us a full audit trail and a cheap idempotency check.
    """
    __tablename__ = 'issue_webhook_event'

    id                  = db.Column(db.Integer, primary_key=True)
    delivery_id         = db.Column(db.String(100), nullable=False, unique=True, index=True)
    event_type          = db.Column(db.String(50), nullable=True)
    action              = db.Column(db.String(50), nullable=True)
    github_issue_number = db.Column(db.Integer, nullable=True, index=True)
    payload_json        = db.Column(db.Text, nullable=True)
    signature_valid     = db.Column(db.Boolean, nullable=False, default=False)
    processed           = db.Column(db.Boolean, nullable=False, default=False)
    processing_error    = db.Column(db.Text, nullable=True)
    received_at         = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


class SupportConversation(db.Model):
    """One-to-one support thread between a user and the admin team."""
    __tablename__ = 'support_conversation'

    id = db.Column(db.Integer, primary_key=True)
    public_id = db.Column(db.String(16), nullable=False, unique=True, index=True)
    user_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    assigned_admin_id = db.Column(db.String(120), db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True, index=True)

    status = db.Column(db.String(20), nullable=False, default='open', index=True)
    priority = db.Column(db.String(20), nullable=False, default='normal')
    subject = db.Column(db.String(200), nullable=True)

    source_page_url = db.Column(db.String(500), nullable=True)
    app_version = db.Column(db.String(50), nullable=True)
    user_agent = db.Column(db.String(500), nullable=True)

    last_message_at = db.Column(db.DateTime, nullable=True, index=True)
    last_user_message_at = db.Column(db.DateTime, nullable=True)
    last_admin_message_at = db.Column(db.DateTime, nullable=True)

    retention_eligible_at = db.Column(db.DateTime, nullable=True, index=True)
    hard_delete_at = db.Column(db.DateTime, nullable=True, index=True)

    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = db.Column(db.DateTime, nullable=True)
    closed_by = db.Column(db.String(120), nullable=True)

    user = relationship('User', foreign_keys=[user_id], backref=db.backref('support_conversations', cascade='all, delete-orphan', passive_deletes=True))
    assigned_admin = relationship('User', foreign_keys=[assigned_admin_id])
    messages = relationship('SupportMessage', back_populates='conversation', cascade='all, delete-orphan', passive_deletes=True)
    read_states = relationship('SupportConversationReadState', back_populates='conversation', cascade='all, delete-orphan', passive_deletes=True)

    __table_args__ = (
        db.Index('ix_support_conversation_status_last', 'status', 'last_message_at'),
        db.Index('ix_support_conversation_user_status', 'user_id', 'status'),
    )


class SupportMessage(db.Model):
    """Persisted support chat message."""
    __tablename__ = 'support_message'

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('support_conversation.id', ondelete='CASCADE'), nullable=False, index=True)
    sender_type = db.Column(db.String(20), nullable=False)  # user | admin | system
    sender_id = db.Column(db.String(120), nullable=True, index=True)
    body = db.Column(db.Text, nullable=False)
    message_type = db.Column(db.String(20), nullable=False, default='text')
    client_nonce = db.Column(db.String(80), nullable=True)
    metadata_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    edited_at = db.Column(db.DateTime, nullable=True)
    deleted_at = db.Column(db.DateTime, nullable=True)

    conversation = relationship('SupportConversation', back_populates='messages')

    __table_args__ = (
        db.Index('ix_support_message_conversation_created', 'conversation_id', 'created_at'),
        db.UniqueConstraint('conversation_id', 'sender_id', 'client_nonce', name='uq_support_message_client_nonce'),
    )


class SupportConversationReadState(db.Model):
    """Read cursor per user/admin for a support conversation."""
    __tablename__ = 'support_conversation_read_state'

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('support_conversation.id', ondelete='CASCADE'), nullable=False, index=True)
    reader_type = db.Column(db.String(20), nullable=False)  # user | admin
    reader_id = db.Column(db.String(120), nullable=False, index=True)
    last_read_message_id = db.Column(db.Integer, db.ForeignKey('support_message.id', ondelete='SET NULL'), nullable=True)
    last_read_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    conversation = relationship('SupportConversation', back_populates='read_states')
    last_read_message = relationship('SupportMessage', foreign_keys=[last_read_message_id])

    __table_args__ = (
        db.UniqueConstraint('conversation_id', 'reader_type', 'reader_id', name='uq_support_read_state_reader'),
        db.Index('ix_support_read_state_reader', 'reader_type', 'reader_id'),
    )
