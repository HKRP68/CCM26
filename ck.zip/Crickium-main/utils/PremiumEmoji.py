"""Telegram custom-emoji registry for Crickium.

The values in this module are the custom_emoji_id values supplied for the
IPL franchise logos.  Callers can import IPL_TEAM_EMOJIS or get_ipl_team_emoji.
"""

from __future__ import annotations

OVR_EMOJI_ID = "5370784581341422520"

# Wicket/out custom emoji used in the live simulation timelines.  The
# alternative text inside Telegram's <tg-emoji> tag must be a valid Unicode
# emoji, not the literal letter ``W``, otherwise Telegram ignores the custom
# emoji entity and leaves plain text behind.
WICKET_OUT_EMOJI_ID = "5431667456454175520"
WICKET_OUT_EMOJI_FALLBACK = "🏏"

# Impact Player custom emojis. These IDs are reserved exclusively for
# Impact Player IN/OUT names and must not alter any existing emoji registry.
IMPACT_IN_EMOJI_ID = "5449683594425410231"
IMPACT_IN_EMOJI_FALLBACK = "⚡"
IMPACT_OUT_EMOJI_ID = "5447183459602669338"
IMPACT_OUT_EMOJI_FALLBACK = "❌"


def impact_in_emoji_html() -> str:
    return f'<tg-emoji emoji-id="{IMPACT_IN_EMOJI_ID}">{IMPACT_IN_EMOJI_FALLBACK}</tg-emoji>'


def impact_out_emoji_html() -> str:
    return f'<tg-emoji emoji-id="{IMPACT_OUT_EMOJI_ID}">{IMPACT_OUT_EMOJI_FALLBACK}</tg-emoji>'


def impact_player_name_html(name: str, impact_type: str) -> str:
    """Prefix an Impact Player name with its dedicated custom emoji."""
    name = str(name)
    if "<tg-emoji" in name:
        return name
    prefix = impact_in_emoji_html() if str(impact_type).lower() == "in" else impact_out_emoji_html()
    return f"{prefix} {name}"


IPL_TEAM_EMOJIS: dict[str, str] = {
    "CSK": "6233466459670978723",
    "DC": "6231082473648823467",
    "GT": "6230832996178468360",
    "KKR": "6233528822596115283",
    "LSG": "6231206812952042824",
    "MI": "6230762447045664130",
    "PBKS": "6233201756541558942",
    "RR": "6233339143955421619",
    "RCB": "6230812285846166768",
    "SRH": "6233038457589997162",
}


TEAM_FALLBACK_EMOJIS: dict[str, str] = {
    "CSK": "🟡",
    "DC": "🔵",
    "GT": "🔷",
    "KKR": "🟣",
    "LSG": "🔴",
    "MI": "🔵",
    "PBKS": "🔴",
    "RR": "🩷",
    "RCB": "🔴",
    "SRH": "🟠",
}


def get_ipl_team_emoji(team_code: str) -> str | None:
    """Return the configured custom emoji ID for an IPL team code."""
    return IPL_TEAM_EMOJIS.get(str(team_code or "").strip().upper())


def get_ipl_team_fallback_emoji(team_code: str) -> str:
    return TEAM_FALLBACK_EMOJIS.get(str(team_code or "").strip().upper(), "🏏")


def ipl_team_emoji_html(team_code: str) -> str:
    """Return a Telegram HTML custom-emoji entity with a safe Unicode fallback."""
    code = str(team_code or "").strip().upper()
    custom_id = get_ipl_team_emoji(code)
    fallback = get_ipl_team_fallback_emoji(code)
    if custom_id:
        return f'<tg-emoji emoji-id="{custom_id}">{fallback}</tg-emoji>'
    return fallback


def ovr_emoji_html() -> str:
    """Return the custom emoji used for OVR labels, with a safe fallback."""
    return f'<tg-emoji emoji-id="{OVR_EMOJI_ID}">⭐</tg-emoji>'


def wicket_out_emoji_html() -> str:
    """Return the live wicket/out custom emoji as valid Telegram HTML."""
    return f'<tg-emoji emoji-id="{WICKET_OUT_EMOJI_ID}">{WICKET_OUT_EMOJI_FALLBACK}</tg-emoji>'

# Milestone notification custom-emoji slots. Keep these as ``None`` until
# Telegram custom-emoji IDs are supplied. The milestone renderer always falls
# back to the Unicode value while they are None, and automatically gives the
# custom emoji first priority once a valid ID is added here.
MILESTONE_LINE_EMOJIS: dict[str, str | None] = {
    "title": None,
    "player": None,
    "game": None,
    "achievement": None,
    "owner": None,
    "stat": None,
}

# Optional media for milestone alerts. Replace ``file_id`` with a Telegram
# animation/GIF or video file_id later. ``None`` means send the normal text
# alert only for now.
MILESTONE_MEDIA: dict[str, dict[str, str | None]] = {
    "BAT_50": {"type": "animation", "file_id": None},
    "BAT_100": {"type": "animation", "file_id": None},
    "BOWL_3": {"type": "animation", "file_id": None},
    "BOWL_5": {"type": "animation", "file_id": None},
    "HAT_TRICK": {"type": "animation", "file_id": None},
    "PARTNERSHIP": {"type": "animation", "file_id": None},
}

MILESTONE_FALLBACK_EMOJIS: dict[str, str] = {
    "BAT_50": "🏏",
    "BAT_100": "💯",
    "BOWL_3": "🎯",
    "BOWL_5": "🔥",
    "HAT_TRICK": "🎩",
    "PARTNERSHIP": "🤝",
}


def milestone_emoji_html(category: str, fallback: str) -> str:
    """Return custom emoji HTML when configured, otherwise Unicode fallback."""
    custom_id = MILESTONE_LINE_EMOJIS.get(str(category))
    if custom_id:
        return f'<tg-emoji emoji-id="{custom_id}">{fallback}</tg-emoji>'
    return fallback

# ---------------------------------------------------------------------------
# Crickium Quest + Pack currency/UX slots
# ---------------------------------------------------------------------------
# Keep every value None until a real Telegram custom-emoji ID is supplied.
# Helpers below always return the Unicode fallback while a slot is None.
DAILY_QUEST_EMOJI_ID: str | None = None
WEEKLY_QUEST_EMOJI_ID: str | None = None
MONTHLY_QUEST_EMOJI_ID: str | None = None
DONE_QUEST_EMOJI_ID: str | None = None
SIGIL_EMOJI_ID: str | None = None
COINS_EMOJI_ID: str | None = None
RUBIES_EMOJI_ID: str | None = None

QUEST_PERIOD_FALLBACKS: dict[str, str] = {
    "daily": "📅",
    "weekly": "🗓️",
    "monthly": "🌙",
}

CURRENCY_FALLBACKS: dict[str, str] = {
    "sigils": "✨",
    "coins": "🪙",
    "rubies": "💎",
}


def custom_emoji_html(custom_id: str | None, fallback: str) -> str:
    if custom_id:
        return f'<tg-emoji emoji-id="{custom_id}">{fallback}</tg-emoji>'
    return fallback


def quest_period_emoji_html(period_type: str) -> str:
    period = str(period_type or "").lower()
    custom_id = {
        "daily": DAILY_QUEST_EMOJI_ID,
        "weekly": WEEKLY_QUEST_EMOJI_ID,
        "monthly": MONTHLY_QUEST_EMOJI_ID,
    }.get(period)
    return custom_emoji_html(custom_id, QUEST_PERIOD_FALLBACKS.get(period, "🏏"))


def done_quest_emoji_html() -> str:
    return custom_emoji_html(DONE_QUEST_EMOJI_ID, "✅")


def sigil_emoji_html() -> str:
    return custom_emoji_html(SIGIL_EMOJI_ID, CURRENCY_FALLBACKS["sigils"])


def coins_emoji_html() -> str:
    return custom_emoji_html(COINS_EMOJI_ID, CURRENCY_FALLBACKS["coins"])


def rubies_emoji_html() -> str:
    return custom_emoji_html(RUBIES_EMOJI_ID, CURRENCY_FALLBACKS["rubies"])


# Pack-specific custom emoji slots. Replace None with actual custom emoji IDs.
PACK_EMOJI_IDS: dict[str, str | None] = {
    "bronze": None,
    "silver": None,
    "gold": None,
    "diamond": None,
    "platinum": None,
}
PACK_EMOJI_FALLBACKS: dict[str, str] = {
    "bronze": "🥉",
    "silver": "🥈",
    "gold": "🥇",
    "diamond": "💠",
    "platinum": "🏆",
}

# Telegram Pack media file_id slots. Fill these later with real Telegram
# file_ids. None means the handler safely falls back to text-only UI.
PACK_IMAGE_FILE_IDS: dict[str, str | None] = {
    "bronze": None,
    "silver": None,
    "gold": None,
    "diamond": None,
    "platinum": None,
}


def pack_emoji_html(pack_key: str) -> str:
    key = str(pack_key or "").strip().lower()
    return custom_emoji_html(PACK_EMOJI_IDS.get(key), PACK_EMOJI_FALLBACKS.get(key, "📦"))
