from __future__ import annotations
import inspect
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
try:
    from pyrogram.enums import ButtonStyle
except Exception:
    ButtonStyle = None

_PARAMS = set(inspect.signature(InlineKeyboardButton.__init__).parameters)
_SUPPORTS_STYLE = 'style' in _PARAMS
_HINT = {'success':'🟢','danger':'🔴','primary':'🔵'}

def _style_value(style):
    if ButtonStyle is None:
        return style
    return {
        'primary': ButtonStyle.PRIMARY,
        'success': ButtonStyle.SUCCESS,
        'danger': ButtonStyle.DANGER,
    }.get(str(style).lower(), ButtonStyle.DEFAULT)


def _b(text, data, style='primary'):
    if _SUPPORTS_STYLE:
        return InlineKeyboardButton(text, callback_data=data, style=_style_value(style))
    return InlineKeyboardButton(f"{_HINT.get(style,'')} {text}".strip(), callback_data=data)


_ROLE_EMOJI = {'Batsman': '🏏', 'Bowler': '⚡', 'AllRounder': '🔄', 'Wicketkeeper': '🧤'}


def _build(match_id, team_code, player_list, selected_ids, button_style):
    selected = set(int(x) for x in (selected_ids or []))
    rows=[[_b('▶️ Play with your last Playing 11',f'playwpl_recent_xi:{match_id}:{team_code}',button_style)]]
    for i in range(0,len(player_list),2):
        row=[]
        for p in player_list[i:i+2]:
            pid=int(p.get('player_id') or 0)
            name=p.get('name','Player')
            role_icon=_ROLE_EMOJI.get(str(p.get('role') or ''),'🏏')
            ovr=max(int(p.get('bat_level') or 0),int(p.get('bowl_level') or 0))
            mark='✅ ' if pid in selected else ''
            style='success' if pid in selected else button_style
            row.append(_b(f'{mark}{role_icon} {name} • {ovr}', f'playwpl_xi:{match_id}:{team_code}:{pid}', style))
        rows.append(row)
    rows.append([_b('✅ CONFIRM PLAYING XI',f'playwpl_xi_confirm:{match_id}:{team_code}',button_style)])
    return InlineKeyboardMarkup(rows)

def opponent_xi_keyboard(match_id, team_code, player_list, selected_ids):
    return _build(match_id, team_code, player_list, selected_ids, 'danger')
